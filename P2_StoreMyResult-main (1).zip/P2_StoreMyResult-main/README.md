# P2_StoreMyResult
A PHP project to store and retreave Student results.
